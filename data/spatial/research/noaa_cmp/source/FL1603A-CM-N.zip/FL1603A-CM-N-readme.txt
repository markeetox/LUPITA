Metadata Link: https://www.fisheries.noaa.gov/inport/q?keywords=FL1603A-CM-N
