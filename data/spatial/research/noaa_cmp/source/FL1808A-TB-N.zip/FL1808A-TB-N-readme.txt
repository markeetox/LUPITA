Metadata Link: https://www.fisheries.noaa.gov/inport/q?keywords=FL1808A-TB-N
