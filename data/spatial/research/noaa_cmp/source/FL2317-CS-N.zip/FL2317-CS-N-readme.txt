Metadata Link: https://www.fisheries.noaa.gov/inport/q?keywords=FL2317-CS-N
